
// DIA Guest And Members Register - main.dart
// Place this file at: lib/main.dart
// NOTE: This package is a starter. To create full project, run `flutter create <project>` then replace lib/main.dart and add assets + pubspec.yaml dependencies as provided.

import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lock orientation to portrait
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(DiaRegisterApp());
}

class DiaRegisterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DIA Guest And Members Register',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  Database? db;

  @override
  void initState() {
    super.initState();
    _initDb();
  }

  Future<void> _initDb() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = p.join(documentsDirectory.path, "dia_register.db");
    db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE guests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first TEXT,
          last TEXT,
          phone TEXT,
          email TEXT,
          day INTEGER,
          month INTEGER,
          created_at TEXT
        )
      ''');
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFf2c94c), Color(0xFF2d9cdb), Color(0xFFb22222)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/logo.png', width: 96, height: 96),
                SizedBox(width: 12),
                Flexible(
                  child: Text(
                    'DIVINE\nINTERVENTION\nASSEMBLY',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.bold),
                  ),
                )
              ],
            ),
            SizedBox(height: 24),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(height: 6),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFb22222),
                        minimumSize: Size(double.infinity, 60),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18)),
                      ),
                      child: Text('TAP TO REGISTER', style: TextStyle(fontSize: 20)),
                      onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => RegisterFormScreen(db: db))),
                    ),
                    SizedBox(height: 18),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => AdminLoginScreen(db: db))),
                        child: Text('Admin', style: TextStyle(color: Colors.white70)),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RegisterFormScreen extends StatefulWidget {
  final Database? db;
  RegisterFormScreen({this.db});

  @override
  _RegisterFormScreenState createState() => _RegisterFormScreenState();
}
class _RegisterFormScreenState extends State<RegisterFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController firstController = TextEditingController();
  final TextEditingController lastController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  DateTime? _pickedDate;

  Future<void> _pickDayMonth() async {
    DateTime now = DateTime.now();
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 100),
      lastDate: DateTime(now.year + 1),
    );
    if (picked != null) {
      setState(() => _pickedDate = picked);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_pickedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please choose birthday')));
      return;
    }

    final db = widget.db;
    if (db == null) return;

    await db.insert('guests', {
      'first': firstController.text.trim(),
      'last': lastController.text.trim(),
      'phone': phoneController.text.trim(),
      'email': emailController.text.trim(),
      'day': _pickedDate!.day,
      'month': _pickedDate!.month,
      'created_at': DateTime.now().toIso8601String(),
    });

    firstController.clear();
    lastController.clear();
    phoneController.clear();
    emailController.clear();
    setState(() => _pickedDate = null);

    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ThankYouScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Center(
          child: Card(
            color: Colors.white.withOpacity(0.95),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Register', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    SizedBox(height: 12),
                    TextFormField(
                      controller: firstController,
                      decoration: InputDecoration(labelText: 'First Name'),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter first name' : null,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      controller: lastController,
                      decoration: InputDecoration(labelText: 'Surname'),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter surname' : null,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      controller: phoneController,
                      decoration: InputDecoration(labelText: 'Phone Number'),
                      keyboardType: TextInputType.phone,
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter phone' : null,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: 'Email Address (optional)'),
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return null;
                        final pattern = RegExp(r"^[^@\s]+@[^@\s]+\.[^@\s]+$");
                        return pattern.hasMatch(v.trim()) ? null : 'Invalid email';
                      },
                    ),
                    SizedBox(height: 8),
                    InkWell(
                      onTap: _pickDayMonth,
                      child: InputDecorator(
                        decoration: InputDecoration(labelText: 'Birthday (day / month)'),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_pickedDate == null ? 'Select' : DateFormat('MMM dd').format(_pickedDate!)),
                            Icon(Icons.calendar_month)
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF1E88E5),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _submit,
                        child: Text('SUBMIT', style: TextStyle(fontSize: 18)),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ThankYouScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 24),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFFf2c94c), Color(0xFF2d9cdb), Color(0xFFb22222)]),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, size: 96, color: Colors.white),
            SizedBox(height: 16),
            Text('Thank you for registering', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text('We appreciate your visit to Divine Intervention Assembly.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
            SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black),
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
              child: Text('Done'),
            )
          ],
        ),
      ),
    );
  }
}

class AdminLoginScreen extends StatefulWidget {
  final Database? db;
  AdminLoginScreen({this.db});

  @override
  _AdminLoginScreenState createState() => _AdminLoginScreenState();
}
class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final TextEditingController passCtrl = TextEditingController();
  String savedPass = '1234';

  @override
  void initState() {
    super.initState();
    _loadPass();
  }

  Future<void> _loadPass() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      savedPass = prefs.getString('admin_pass') ?? '1234';
    });
  }

  Future<void> _login() async {
    if (passCtrl.text == savedPass) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AdminScreen(db: widget.db)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid password')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(24),
        child: Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Admin Login', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  SizedBox(height: 12),
                  TextField(
                    controller: passCtrl,
                    decoration: InputDecoration(labelText: 'Password'),
                    obscureText: true,
                  ),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(onPressed: _login, child: Text('Login')),
                      )
                    ],
                  ),
                  SizedBox(height: 8),
                  TextButton(
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setString('admin_pass', '1234');
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Password reset to default: 1234')));
                    },
                    child: Text('Reset to default'),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AdminScreen extends StatefulWidget {
  final Database? db;
  AdminScreen({this.db});

  @override
  _AdminScreenState createState() => _AdminScreenState();
}
class _AdminScreenState extends State<AdminScreen> {
  List<Map<String, dynamic>> rows = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final db = widget.db;
    if (db == null) return;
    final list = await db.query('guests', orderBy: 'created_at DESC');
    setState(() => rows = list);
  }

  Future<void> _exportExcel() async {
    if (!(await _requestStoragePermission())) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Storage permission required')));
      return;
    }

    final excel = Excel.createExcel();
    final sheet = excel['Guests'];
    sheet.appendRow(['First Name', 'Surname', 'Phone', 'Email', 'Day', 'Month', 'Registered At']);
    for (var r in rows) {
      sheet.appendRow([
        r['first'] ?? '',
        r['last'] ?? '',
        r['phone'] ?? '',
        r['email'] ?? '',
        r['day']?.toString() ?? '',
        r['month']?.toString() ?? '',
        r['created_at'] ?? '',
      ]);
    }

    final List<int>? fileBytes = excel.encode();
    if (fileBytes == null) return;

    Directory? directory;
    if (Platform.isAndroid) {
      directory = await getExternalStorageDirectory();
      final downloads = Directory('/storage/emulated/0/Download');
      if (await downloads.exists()) {
        directory = downloads;
      }
    } else {
      directory = await getApplicationDocumentsDirectory();
    }

    String timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
    String fileName = 'dia_guests_$timestamp.xlsx';
    String filePath = p.join(directory!.path, fileName);
    final outFile = File(filePath);
    await outFile.writeAsBytes(fileBytes, flush: true);

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Exported to $filePath')));
  }

  Future<bool> _requestStoragePermission() async {
    if (Platform.isAndroid) {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        status = await Permission.storage.request();
      }
      return status.isGranted;
    }
    return true;
  }

  Future<void> _clearData() async {
    final db = widget.db;
    if (db == null) return;
    await db.delete('guests');
    await _loadData();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Database cleared')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin - Guests'),
        actions: [
          IconButton(onPressed: _exportExcel, icon: Icon(Icons.file_download)),
          IconButton(onPressed: _clearData, icon: Icon(Icons.delete_forever)),
        ],
      ),
      body: rows.isEmpty
          ? Center(child: Text('No guests yet'))
          : ListView.builder(
              itemCount: rows.length,
              itemBuilder: (_, i) {
                final item = rows[i];
                return ListTile(
                  title: Text('${item['first']} ${item['last'] ?? ''}'),
                  subtitle: Text('${item['phone'] ?? ''} • ${item['email'] ?? ''}'),
                  trailing: Text('${item['day']}/${item['month']}'),
                );
              },
            ),
    );
  }
}
