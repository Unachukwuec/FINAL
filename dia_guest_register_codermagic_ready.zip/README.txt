
DIA Guest And Members Register
==============================

This package is a ready-to-use Flutter starter for an offline guest register app.
It includes:
- Kiosk UI with church logo
- Offline SQLite storage for guest entries
- Admin screen protected by default password: 1234
- Export guest list to .xlsx (Excel) saved to device Downloads
- Thank-you confirmation screen
- Locked to portrait orientation

Quick setup
-----------

1. Ensure Flutter SDK is installed and `flutter doctor` passes.

2. Create a Flutter project (recommended) and replace lib/main.dart and pubspec.yaml:
   ```bash
   flutter create dia_guest_register
   cd dia_guest_register
   ```
   Replace the generated `lib/main.dart` with the provided `lib/main.dart` file in this zip.
   Replace `pubspec.yaml` with the provided one (or merge dependencies manually).

3. Place the logo file at:
   ```
   assets/logo.png
   ```

4. Get packages:
   ```bash
   flutter pub get
   ```

Build APK (Android)
-------------------
1. Connect Android device or use emulator.
2. Run:
   ```bash
   flutter build apk --release
   ```
3. Resulting APK:
   ```
   build/app/outputs/flutter-apk/app-release.apk
   ```
4. Copy APK to tablet and install (Enable Install unknown apps).

Build iOS (.ipa)
----------------
(Requires macOS + Xcode)

1. Open iOS workspace:
   ```bash
   open ios/Runner.xcworkspace
   ```
2. In Xcode, select your signing team and device.
3. Build & Run to test on device.
4. To create an installable .ipa:
   Product -> Archive -> Distribute App -> Ad Hoc or Development -> Export .ipa

Notes
-----
- Admin default password is `1234`. To change, set SharedPreferences key `admin_pass` or modify default in code.
- On Android, exported file will attempt to save to /storage/emulated/0/Download if available.
- For production or multi-device deployments consider adding secure admin authentication and backups.

If you want, I can:
- Split project into full Flutter project (already done in this zip as minimal starter)
- Provide a compiled APK file (I cannot compile iOS .ipa here)
- Walk you through building on your machine step-by-step
